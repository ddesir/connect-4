[Start]
You wake up in a room with only a knife, a banana, and some dishsoap. A hooded man comes into the room and demands that you choose an item. You choose:
#knife
#banana
#dishsoap